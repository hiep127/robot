#!/usr/bin/env python
# license removed for brevity

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseActionGoal

def move_base_client():
    
    rospy.init_node('movebase_client_py')
    pub = rospy.Publisher('move_base/goal', MoveBaseActionGoal, queue_size=1)
    rate = rospy.Rate(10)
    client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
    wait = client.wait_for_server()
    while not wait:
	rospy.loginfo("waiting for server")
    move_base_goal = MoveBaseGoal()
    move_base_goal.target_pose.header.frame_id = "map"
    move_base_goal.target_pose.header.stamp = rospy.Time.now()
    move_base_goal.target_pose.pose.position.x = 1.0
    move_base_goal.target_pose.pose.position.y = 0.5 
    move_base_goal.target_pose.pose.orientation.w = 1.0
    goal=MoveBaseActionGoal()
    goal.goal = move_base_goal
    pub.publish(goal)
    rospy.loginfo("publising goal")
    rospy.spin()

if __name__ == '__main__':
    try:
        move_base_client()
    except rospy.ROSInterruptException:
        pass
        

